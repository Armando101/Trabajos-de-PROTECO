public class Piano implements notaDo {

	public void Localizar() {
			System.out.println("La nota Do se encuetra detras de las dos teclas negras");
		}
}