public class Guitarra implements notaDo {

		public void Localizar() {
			System.out.println("La nota Do se encuetra en el tercer traste de la quinta cuerda");
		}

}