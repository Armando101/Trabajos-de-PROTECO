public interface notaDo {
	public void Localizar();
}