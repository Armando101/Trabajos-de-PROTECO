public class Bajo implements notaDo {
	
	public void Localizar() {
			System.out.println("La nota Do se encuetra en el tercer traste de la tercera cuerda");
		}

}