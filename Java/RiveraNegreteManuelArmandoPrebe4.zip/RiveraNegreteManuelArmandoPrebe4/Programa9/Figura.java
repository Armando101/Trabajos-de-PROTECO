public interface Figura {
	
	public abstract double Area();
	public abstract double Perimetro();
}